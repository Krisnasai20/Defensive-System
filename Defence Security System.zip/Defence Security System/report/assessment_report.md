# Security Assessment Report: SecureNotes Local Practice Application

**Date:** 2026-11-04  
**Target Application:** SecureNotes (`http://localhost:5000`)  
**Assessment Type:** Local Defensive Security Assessment & Code Audit  
**Author:** Security Analyst  
**Status:** Initial Assessment (Pre-Remediation)  

---

## 1. Executive Summary
A comprehensive defensive security evaluation was conducted against the **SecureNotes** local practice web application running in an isolated environment on `http://127.0.0.1:5000`. The review evaluated runtime configuration, authentication mechanisms, input handling, dependency risks, and logging practices.

During this assessment, **8 distinct security findings** were identified and practically verified. The findings include **1 Critical**, **3 High**, **3 Medium**, and **1 Low** severity vulnerabilities. The most critical vulnerabilities expose the application to full database compromise (SQL Injection), arbitrary client-side script execution (Reflected XSS), and credential compromise via obsolete cryptography (MD5 hashing).

Immediate remediation of the top three risks is strongly recommended to establish a resilient security baseline.

---

## 2. Assessment Scope & Methodology
The assessment adhered strictly to the rules established in `SCOPE.md`:
- **In-Scope:** Application code under `app/` and local endpoints at `http://127.0.0.1:5000`.
- **Out-of-Scope:** External networks, non-local services, host OS exploitation, and Denial of Service attacks.
- **Data Policy:** Only synthetic, placeholder test data (`tester@example.test`) was utilized.
- **Testing Approach:** Combination of static code analysis, configuration review, and non-destructive automated HTTP verification probes executed via `assess.py`.

---

## 3. Findings Summary Table

| Finding ID | Finding Title | Severity | CVSS v3.1 | CWE | Target Component |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **F-001** | SQL Injection in Notes Search Feature | **Critical** | 9.8 | CWE-89 | `GET /notes?q=` |
| **F-002** | Reflected Cross-Site Scripting (XSS) in Search Output | **High** | 7.2 | CWE-79 | `GET /notes?q=` |
| **F-003** | Use of Cryptographically Broken Hash Algorithm (MD5) | **High** | 7.5 | CWE-328 | `app/app.py` (Auth) |
| **F-004** | Debug Mode Enabled in Runtime Server Configuration | **High** | 7.5 | CWE-489 | `app/app.py` (`debug=True`) |
| **F-005** | Lack of Rate Limiting on Authentication Endpoint | **Medium** | 5.3 | CWE-307 | `POST /login` |
| **F-006** | Sensitive Credential Exposure in Application Logs | **Medium** | 5.5 | CWE-532 | `app/app.py` (Logging) |
| **F-007** | Known Vulnerabilities in Outdated Pinned Dependencies | **Medium** | 6.5 | CWE-1104 | `app/requirements.txt` |
| **F-008** | Missing Standard HTTP Security Headers | **Low** | 3.7 | CWE-693 | Global HTTP Responses |

---

## 4. Detailed Findings

### F-001: SQL Injection in Notes Search Feature
- **Severity:** Critical (CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H - 9.8)
- **Area:** Input Validation
- **CWE:** CWE-89 (Improper Neutralization of Special Elements used in an SQL Command)
- **Description:** The search functionality in `/notes` concatenates user input directly into an SQLite SQL string without parameterization or escaping.
- **Vulnerable Code (`app/app.py`):**
  ```python
  sql_query = f"SELECT id, title, content, created_at FROM notes WHERE user_id = {user_id} AND (title LIKE '%{query}%' OR content LIKE '%{query}%') ORDER BY id DESC"
  cursor.execute(sql_query)
  ```
- **Reproduction Steps:**
  1. Authenticate with synthetic credentials (`tester` / `Password123!`).
  2. Navigate to `http://localhost:5000/notes?q=test'`.
  3. Observe that an unhandled SQLite syntax error is raised and reflected in the UI: `Database error during search: unrecognized token: "'% ORDER BY id DESC"`.
  4. Submit query probe `http://localhost:5000/notes?q=test'%20OR%20'1'='1`.
  5. Observe that the SQL condition evaluates to true, bypassing query filters.
- **Evidence:** Refer to `evidence/03_input_validation_sqli.txt`.
- **Impact:** An authenticated user can bypass query constraints, exfiltrate data from other tables or users, or tamper with stored database records.
- **Recommended Fix:** Replace dynamic string formatting with parameterized SQL queries using standard `?` placeholders:
  ```python
  pattern = f"%{query}%"
  cursor.execute(
      "SELECT id, title, content, created_at FROM notes WHERE user_id = ? AND (title LIKE ? OR content LIKE ?) ORDER BY id DESC",
      (user_id, pattern, pattern)
  )
  ```

---

### F-002: Reflected Cross-Site Scripting (XSS) in Search Output
- **Severity:** High (CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N - 7.2)
- **Area:** Input Validation & Output Encoding
- **CWE:** CWE-79 (Improper Neutralization of Input During Web Page Generation)
- **Description:** The keyword passed to the search parameter `q` is passed to the Jinja2 template and explicitly rendered using the `| safe` filter, disabling Flask's built-in contextual HTML auto-escaping.
- **Vulnerable Code (`app/templates/notes.html`):**
  ```html
  Search results for: <strong>{{ query_rendered | safe }}</strong> ({{ notes|length }} results)
  ```
- **Reproduction Steps:**
  1. Authenticate as the test user.
  2. Submit the benign test payload: `http://localhost:5000/notes?q=%3Cscript%20id='xss-probe'%3Econsole.log('XSS_VERIFIED')%3C/script%3E`.
  3. Inspect the returned HTML DOM.
  4. Confirm that `<script id='xss-probe'>console.log('XSS_VERIFIED')</script>` is reflected verbatim without entity escaping.
- **Evidence:** Refer to `evidence/04_input_validation_xss.txt`.
- **Impact:** An attacker could craft a malicious link leading to arbitrary JavaScript execution in the victim's browser session, resulting in session hijacking, CSRF, or phishing.
- **Recommended Fix:** Remove the `| safe` filter and allow Jinja2's default auto-escaping to encode special HTML characters (`&`, `<`, `>`, `"`, `'`):
  ```html
  Search results for: <strong>{{ raw_query }}</strong> ({{ notes|length }} results)
  ```

---

### F-003: Use of Cryptographically Broken Hash Algorithm (MD5)
- **Severity:** High (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N - 7.5)
- **Area:** Authentication & Cryptography
- **CWE:** CWE-328 (Use of Weak Hash) / CWE-916 (Use of Password Hash With Insufficient Computational Effort)
- **Description:** User passwords are encrypted using unsalted MD5 hashing (`hashlib.md5(password.encode()).hexdigest()`). MD5 is computationally trivial to invert using rainbow tables or commodity hardware brute-forcing.
- **Vulnerable Code (`app/app.py`):**
  ```python
  def hash_password(password: str) -> str:
      return hashlib.md5(password.encode('utf-8')).hexdigest()
  ```
- **Reproduction Steps:**
  1. Inspect the SQLite `users` table: `SELECT username, password_hash FROM users WHERE username='tester';`.
  2. Observe stored digest: `207023ccb44feb4d7dadca005ce29a64` (32 hex characters, standard MD5 digest of `Password123!`).
- **Evidence:** Refer to `evidence/02_authentication_ratelimit.txt`.
- **Impact:** In the event of database access or backup compromise, all user passwords can be cracked almost instantaneously.
- **Recommended Fix:** Utilize a standard key derivation function such as PBKDF2-HMAC-SHA256, bcrypt, or Argon2 via Werkzeug's built-in `generate_password_hash` and `check_password_hash`:
  ```python
  from werkzeug.security import generate_password_hash, check_password_hash
  # Store: generate_password_hash(password, method='pbkdf2:sha256')
  # Verify: check_password_hash(user['password_hash'], password)
  ```

---

### F-004: Debug Mode Enabled in Runtime Server Configuration
- **Severity:** High (CVSS:3.1/AV:L/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H - 7.5)
- **Area:** Configuration & Deployment
- **CWE:** CWE-489 (Active Debug Code)
- **Description:** The Flask application runner explicitly enables debug mode (`app.run(debug=True)`). This activates the Werkzeug interactive debugger, which includes an interactive Python evaluation console upon unhandled exceptions.
- **Reproduction Steps:**
  1. Inspect `app/app.py` line 180: `app.run(host='127.0.0.1', port=5000, debug=True)`.
  2. Start the application and observe terminal log: `* Debugger is active!` and `* Debugger PIN: XXX-XXX-XXX`.
- **Evidence:** Refer to `evidence/01_configuration_headers.txt`.
- **Impact:** Exposes stack traces, internal paths, and provides interactive remote code execution capabilities if the debugger PIN is obtained or bypassed.
- **Recommended Fix:** Set `debug=False` and manage environment variables with `FLASK_ENV=production` or `os.getenv('FLASK_DEBUG', '0')`.

---

### F-005: Lack of Rate Limiting on Authentication Endpoint
- **Severity:** Medium (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N - 5.3)
- **Area:** Authentication & Abuse Prevention
- **CWE:** CWE-307 (Improper Restriction of Excessive Authentication Attempts)
- **Description:** The `POST /login` route allows an unlimited number of failed login attempts without throttling, temporary lockout, or CAPTCHA gating.
- **Reproduction Steps:**
  1. Issue 15 consecutive invalid login attempts for user `tester`.
  2. Observe that all 15 requests return HTTP 200 with no delay, IP block, or HTTP 429 response.
- **Evidence:** Refer to `evidence/02_authentication_ratelimit.txt`.
- **Impact:** Facilitates automated brute-force attacks and credential stuffing against user accounts.
- **Recommended Fix:** Implement an in-memory or Redis-backed rate limiter (e.g., Flask-Limiter or custom IP/account sliding window limit of 5 failed attempts per minute).

---

### F-006: Sensitive Credential Exposure in Application Logs
- **Severity:** Medium (CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N - 5.5)
- **Area:** Logging & Monitoring
- **CWE:** CWE-532 (Insertion of Sensitive Information into Log File)
- **Description:** The authentication handler prints user-submitted passwords directly into standard log streams at the `INFO` level.
- **Vulnerable Code (`app/app.py`):**
  ```python
  logger.info(f"Authentication attempt: username='{username}' password='{password}'")
  ```
- **Reproduction Steps:**
  1. Submit a login attempt with test credentials.
  2. Review application standard log output.
  3. Confirm the password string appears in cleartext.
- **Evidence:** Refer to `evidence/06_logging.txt`.
- **Impact:** System administrators, log collection pipelines, or unauthorized personnel with access to logs can view user credentials.
- **Recommended Fix:** Remove credentials from log formatters; only log anonymized account metadata and boolean success/failure status.

---

### F-007: Known Vulnerabilities in Outdated Pinned Dependencies
- **Severity:** Medium (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H - 6.5)
- **Area:** Dependency Management
- **CWE:** CWE-1104 (Use of Unmaintained Third Party Components)
- **Description:** `app/requirements.txt` pins `Werkzeug==2.1.2` and `Flask==2.1.3`. Werkzeug < 2.3.8 is subject to Denial of Service via multipart/form-data parser resource exhaustion (CVE-2023-46136) and header parsing flaws (CVE-2022-29361).
- **Reproduction Steps:**
  1. Review `app/requirements.txt`.
  2. Cross-reference pinned package versions against Python advisory databases.
- **Evidence:** Refer to `evidence/05_dependencies.txt`.
- **Impact:** Potential application denial of service or exploitation of unpatched upstream flaws.
- **Recommended Fix:** Update `requirements.txt` to modern supported versions (`Flask>=3.0.0`, `Werkzeug>=3.0.1`).

---

### F-008: Missing Standard HTTP Security Headers
- **Severity:** Low (CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:L/A:N - 3.7)
- **Area:** Configuration & HTTP Hardening
- **CWE:** CWE-693 (Protection Mechanism Failure)
- **Description:** Responses from `http://localhost:5000` lack standard defense-in-depth HTTP security headers, including `Content-Security-Policy`, `X-Frame-Options`, `X-Content-Type-Options`, and `Referrer-Policy`.
- **Reproduction Steps:**
  1. Perform `GET /login`.
  2. Inspect response headers; verify absence of security policy directives.
- **Evidence:** Refer to `evidence/01_configuration_headers.txt`.
- **Impact:** Increased susceptibility to clickjacking (`X-Frame-Options`), MIME-type sniffing, and unmitigated XSS impact.
- **Recommended Fix:** Register an `after_request` hook in Flask to attach standard headers:
  ```python
  @app.after_request
  def set_security_headers(response):
      response.headers['X-Content-Type-Options'] = 'nosniff'
      response.headers['X-Frame-Options'] = 'DENY'
      response.headers['Content-Security-Policy'] = "default-src 'self'"
      response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
      return response
  ```

---

## 5. Remediation Priority Roadmap
Based on exploitability, impact, and ease of remediation, the top three risks designated for immediate remediation and verification are:

1. **Top Risk 1 (F-001): SQL Injection in Search** -> Transition to parameterized SQLite queries.
2. **Top Risk 2 (F-002): Reflected Cross-Site Scripting (XSS)** -> Remove Jinja2 `| safe` filter and enforce HTML auto-escaping.
3. **Top Risk 3 (F-003): Insecure Password Hashing** -> Replace unsalted MD5 with Werkzeug PBKDF2:SHA256 salted hashing.

# Defensive Security Assessment Capstone — Submission Checklist

**Student / Analyst:** Security Analyst  
**Target Application:** SecureNotes (`http://localhost:5000`)  
**Project Repository:** Local Defensive Security Assessment Workspace  
**Status:** Completed & Ready for Submission  

---

## Passing Criteria Checklist

### 1. Scoping & Authorization
- [x] **Target Description:** Clear description of the application architecture, stack, and functionality (`SCOPE.md` §1).
- [x] **In-Scope Boundaries:** Explicitly limited to `http://localhost:5000` and `app/` codebase (`SCOPE.md` §2).
- [x] **Out-of-Scope Boundaries:** Excluded all external hosts, third-party services, OS exploitation, and DoS attacks (`SCOPE.md` §3).
- [x] **Authorization Statement:** Explicit legal declaration of ownership and consent for defensive auditing (`SCOPE.md` §4).
- [x] **Rules of Engagement (RoE):** Defined ethical testing rules, local boundary restrictions, non-destructive probe constraints (`SCOPE.md` §5).
- [x] **Threat Model:** Component-level STRIDE threat matrix mapping potential threats to severity (`SCOPE.md` §6).

### 2. Five-Area Security Testing & Evidence
- [x] **Configuration Testing:** Audited Flask runtime debug flag and HTTP security headers (`evidence/01_configuration_headers.txt`).
- [x] **Authentication Testing:** Evaluated password hashing scheme (MD5) and tested login brute-force resistance (`evidence/02_authentication_ratelimit.txt`).
- [x] **Input Validation Testing:** Verified SQL injection via syntax/logic probes and Reflected XSS via probe reflection (`evidence/03_input_validation_sqli.txt`, `evidence/04_input_validation_xss.txt`).
- [x] **Dependency Auditing:** Evaluated pinned dependencies in `requirements.txt` against known CVE advisories (`evidence/05_dependencies.txt`).
- [x] **Logging Security:** Verified exposure of cleartext passwords in authentication log handlers (`evidence/06_logging.txt`).
- [x] **Evidence Sanitization:** All evidence files contain strictly synthetic test data and are free from real credentials, secrets, or PII.

### 3. Formal Reporting
- [x] **Assessment Report (Markdown):** Detailed report with executive summary, methodology, findings table, reproducible steps, impact, and fixes (`report/assessment_report.md`).
- [x] **Assessment Report (PDF):** Formatted standalone PDF deliverable with tables and styling (`report/assessment_report.pdf`).
- [x] **Verified Findings Only:** All 8 reported findings (F-001 through F-008) are backed by verifiable test executions.

### 4. Remediation & Retesting
- [x] **Top Risk 1 Fixed (F-001 SQLi):** Parameterized SQLite queries implemented (`git commit: fix(sqli): parameterize notes search query [F-001]`).
- [x] **Top Risk 2 Fixed (F-002 XSS):** Removed `| safe` bypass filter to enforce auto-escaping (`git commit: fix(xss): remove raw safe filter and enforce html escaping [F-002]`).
- [x] **Top Risk 3 Fixed (F-003 Weak Hashing):** Upgraded from unsalted MD5 to PBKDF2:SHA256 (`git commit: fix(auth): replace md5 with pbkdf2 password hashing [F-003]`).
- [x] **One Git Commit per Fix:** Each fix is isolated in an individual, atomic git commit.
- [x] **Regression Retesting:** Executed `retest.py` with identical probes; verified that all 3 top risks are CLOSED.
- [x] **Retest Documentation:** Documented before/after status matrix and verification evidence (`report/retest.md` and `evidence/07_retest_verification.txt`).

### 5. Deliverable & Size Constraints
- [x] **Single-Link Submission Ready:** All source code, evidence, reports, and scripts reside in one unified workspace/repository.
- [x] **Size Constraint Compliant:** Total folder size is **~0.17 MB**, well below the 25 MB ceiling.
- [x] **Clean Repository:** `.gitignore` excludes `venv/`, `node_modules/`, `__pycache__/`, logs, and temporary binaries.
- [x] **Comprehensive README:** Detailed run guide, test procedures, file map, and findings summary (`README.md`).


# Security Assessment Scope & Rules of Engagement

## 1. Target Application Description
**Application Name:** SecureNotes Local Practice Application  
**Architecture:** Python 3.12 / Flask 2.1.3 micro-framework with SQLite persistence and Jinja2 templating.  
**Functionality:** User registration, credential authentication, personal note creation/management, and keyword note searching.  
**Deployment:** Local development server running on `http://127.0.0.1:5000` (`localhost:5000`).

---

## 2. In-Scope Targets
Testing is strictly restricted to:
- **Application Endpoints:**
  - `GET /` - Root index redirection
  - `GET /login`, `POST /login` - User authentication
  - `GET /register`, `POST /register` - User registration
  - `GET /logout` - Session invalidation
  - `GET /notes` - Note dashboard and note keyword search parameter (`q`)
  - `POST /notes/create` - Note authoring endpoint
- **Application Codebase:**
  - Files under `app/` (`app.py`, `requirements.txt`, templates under `app/templates/`, `notes.db`).
- **Target URL & Port:**
  - `http://localhost:5000` / `http://127.0.0.1:5000` exclusively.

---

## 3. Out-of-Scope Targets
The following systems, hosts, and actions are strictly forbidden and out-of-scope:
- Any external hostname, domain, API, or third-party service (zero external network traffic).
- Any local port or service other than `localhost:5000`.
- Underlying operating system attack, host privilege escalation, kernel exploitation, or local host services.
- Denial of Service (DoS / DDoS), brute-force volumetric resource exhaustion, or destructive data wiping.
- Real credentials, production passwords, or third-party personal data.

---

## 4. Authorization Statement
**Owner Authorization:** The operator is the sole developer and legal administrator of this practice workspace and application instance. Complete authorization is granted to conduct local defensive security assessment, static analysis, configuration auditing, authenticated vulnerability verification, and remediation retesting against this local sandbox instance (`http://localhost:5000`).

---

## 5. Rules of Engagement (RoE)
1. **Local-Only Boundary:** All audit requests and traffic must originate from and terminate at `127.0.0.1:5000`.
2. **Synthetic Data Policy:** Only synthetic, placeholder test data (e.g., `tester@example.test`, mock passwords, dummy notes) shall be generated and submitted.
3. **Non-Destructive Testing:** Tests must preserve basic application availability and avoid dropping system tables or damaging system files.
4. **Evidence Sanitization:** All recorded evidence must exclude sensitive environment paths or unintended private host details.
5. **No Weaponized Payloads:** Vulnerability verification relies on minimal, non-weaponized diagnostic test probes (e.g. single quote string break character `'`, harmless HTML markers like `<b id="test">xss</b>`, or timing probes) without malicious payload execution.

---

## 6. Threat Model (STRIDE)

| Threat Category | Target Component | Threat Scenario & Vector | Severity |
| :--- | :--- | :--- | :--- |
| **Spoofing** | `/login`, Session cookies | Weak session keys or missing cookie protection could allow identity impersonation; lack of rate-limiting enables credential guessing. | High |
| **Tampering** | `/notes` search query | Lack of parameterization allows SQL structure tampering (SQL Injection). | Critical |
| **Repudiation** | Audit logs / Authentication | Cleartext password logging or lack of structured audit trails impedes forensic validation. | Medium |
| **Information Disclosure** | Flask debug mode / Search | Stack traces with interactive debug console disclose source internals; SQL errors disclose schema. | High |
| **Denial of Service** | Application worker | Unindexed expensive queries or regex backtracking; unthrottled brute-force attempts. | Medium |
| **Elevation of Privilege** | Session / SQLi | Cross-Site Scripting (XSS) in note search could hijack user sessions or execute unauthorized UI actions. | High |

import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

pdf_path = "report/assessment_report.pdf"
doc = SimpleDocTemplate(
    pdf_path,
    pagesize=letter,
    rightMargin=40,
    leftMargin=40,
    topMargin=40,
    bottomMargin=40
)

styles = getSampleStyleSheet()

# Custom styles
title_style = ParagraphStyle(
    'DocTitle',
    parent=styles['Heading1'],
    fontName='Helvetica-Bold',
    fontSize=22,
    leading=26,
    textColor=colors.HexColor('#1a2a3a'),
    spaceAfter=6
)

subtitle_style = ParagraphStyle(
    'DocSubtitle',
    parent=styles['Normal'],
    fontName='Helvetica',
    fontSize=11,
    leading=15,
    textColor=colors.HexColor('#555555'),
    spaceAfter=15
)

h1_style = ParagraphStyle(
    'Heading1_Custom',
    parent=styles['Heading2'],
    fontName='Helvetica-Bold',
    fontSize=14,
    leading=18,
    textColor=colors.HexColor('#0b3c61'),
    spaceBefore=14,
    spaceAfter=8
)

h2_style = ParagraphStyle(
    'Heading2_Custom',
    parent=styles['Heading3'],
    fontName='Helvetica-Bold',
    fontSize=11,
    leading=14,
    textColor=colors.HexColor('#222222'),
    spaceBefore=10,
    spaceAfter=4
)

body_style = ParagraphStyle(
    'Body_Custom',
    parent=styles['Normal'],
    fontName='Helvetica',
    fontSize=9.5,
    leading=13.5,
    textColor=colors.HexColor('#2c3e50'),
    spaceAfter=6
)

code_style = ParagraphStyle(
    'Code_Custom',
    parent=styles['Code'],
    fontName='Courier',
    fontSize=8,
    leading=11,
    textColor=colors.HexColor('#990000'),
    backColor=colors.HexColor('#f7f7f7'),
    spaceAfter=6
)

story = []

# Title & Metadata
story.append(Paragraph("Security Assessment Report", title_style))
story.append(Paragraph("<b>Target:</b> SecureNotes Practice App (http://localhost:5000) &nbsp;|&nbsp; <b>Date:</b> November 2026 &nbsp;|&nbsp; <b>Status:</b> Pre-Remediation", subtitle_style))
story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#0b3c61'), spaceAfter=12))

# Executive Summary
story.append(Paragraph("1. Executive Summary", h1_style))
story.append(Paragraph(
    "A defensive security evaluation was conducted against the SecureNotes local practice application. "
    "The assessment tested application runtime configuration, authentication mechanisms, input validation, "
    "dependency vulnerabilities, and logging hygiene. A total of <b>8 findings</b> were verified: "
    "<b>1 Critical</b>, <b>3 High</b>, <b>3 Medium</b>, and <b>1 Low</b>.",
    body_style
))

# Findings Table
story.append(Paragraph("2. Summary Findings Matrix", h1_style))
table_data = [
    [Paragraph("<b>ID</b>", body_style), Paragraph("<b>Finding Title</b>", body_style), Paragraph("<b>Severity</b>", body_style), Paragraph("<b>CWE</b>", body_style), Paragraph("<b>Area</b>", body_style)],
    [Paragraph("F-001", body_style), Paragraph("SQL Injection in Notes Search", body_style), Paragraph("<font color='#d93025'><b>Critical</b></font>", body_style), Paragraph("CWE-89", body_style), Paragraph("Input Validation", body_style)],
    [Paragraph("F-002", body_style), Paragraph("Reflected XSS in Search Query", body_style), Paragraph("<font color='#e67c00'><b>High</b></font>", body_style), Paragraph("CWE-79", body_style), Paragraph("Output Encoding", body_style)],
    [Paragraph("F-003", body_style), Paragraph("Insecure MD5 Password Hashing", body_style), Paragraph("<font color='#e67c00'><b>High</b></font>", body_style), Paragraph("CWE-328", body_style), Paragraph("Authentication", body_style)],
    [Paragraph("F-004", body_style), Paragraph("Debug Mode Active (Werkzeug PIN)", body_style), Paragraph("<font color='#e67c00'><b>High</b></font>", body_style), Paragraph("CWE-489", body_style), Paragraph("Configuration", body_style)],
    [Paragraph("F-005", body_style), Paragraph("Missing Login Rate Limiting", body_style), Paragraph("<font color='#f2994a'><b>Medium</b></font>", body_style), Paragraph("CWE-307", body_style), Paragraph("Authentication", body_style)],
    [Paragraph("F-006", body_style), Paragraph("Cleartext Passwords in Logs", body_style), Paragraph("<font color='#f2994a'><b>Medium</b></font>", body_style), Paragraph("CWE-532", body_style), Paragraph("Logging", body_style)],
    [Paragraph("F-007", body_style), Paragraph("Outdated Pinned Dependencies", body_style), Paragraph("<font color='#f2994a'><b>Medium</b></font>", body_style), Paragraph("CWE-1104", body_style), Paragraph("Dependencies", body_style)],
    [Paragraph("F-008", body_style), Paragraph("Missing HTTP Security Headers", body_style), Paragraph("<font color='#188038'><b>Low</b></font>", body_style), Paragraph("CWE-693", body_style), Paragraph("Hardening", body_style)],
]

t = Table(table_data, colWidths=[45, 195, 65, 75, 110])
t.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e9ecef')),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ('TOPPADDING', (0, 0), (-1, -1), 4),
    ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#ced4da')),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
]))
story.append(t)
story.append(Spacer(1, 10))

# Top Risks Details
story.append(Paragraph("3. Detailed Review of Top 3 Critical/High Risks", h1_style))

# Finding 1
story.append(Paragraph("<b>[F-001] SQL Injection in Notes Search (Critical - CVSS 9.8)</b>", h2_style))
story.append(Paragraph("<b>Description:</b> The query parameter <code>q</code> is concatenated directly into SQLite queries in <code>app/app.py</code> without parameterized placeholders.", body_style))
story.append(Paragraph("<b>Reproduction:</b> Submit <code>GET /notes?q=test'</code> while authenticated as <code>tester@example.test</code>. Unhandled SQL syntax error is returned in response.", body_style))
story.append(Paragraph("<b>Remediation:</b> Implement parameterized query with <code>?</code> placeholder bindings.", body_style))
story.append(Spacer(1, 6))

# Finding 2
story.append(Paragraph("<b>[F-002] Reflected Cross-Site Scripting (High - CVSS 7.2)</b>", h2_style))
story.append(Paragraph("<b>Description:</b> Search term is rendered in Jinja2 template using <code>{{ query_rendered | safe }}</code>, which bypasses auto-escaping.", body_style))
story.append(Paragraph("<b>Reproduction:</b> Request <code>/notes?q=&lt;script id='xss-probe'&gt;...&lt;/script&gt;</code>. Probe is reflected unencoded into HTML DOM.", body_style))
story.append(Paragraph("<b>Remediation:</b> Remove the <code>| safe</code> filter and allow Jinja2 contextual HTML entity encoding.", body_style))
story.append(Spacer(1, 6))

# Finding 3
story.append(Paragraph("<b>[F-003] Insecure Password Hashing with Unsalted MD5 (High - CVSS 7.5)</b>", h2_style))
story.append(Paragraph("<b>Description:</b> Application uses single-round unsalted MD5 digest for user password storage in SQLite.", body_style))
story.append(Paragraph("<b>Reproduction:</b> Database record inspection confirmed 32-character hexadecimal digest matching standard MD5 output.", body_style))
story.append(Paragraph("<b>Remediation:</b> Adopt PBKDF2:SHA256 salted password hashing via <code>werkzeug.security</code>.", body_style))
story.append(Spacer(1, 10))

# Conclusion
story.append(Paragraph("4. Next Steps & Remediation Plan", h1_style))
story.append(Paragraph(
    "Remediate the top three vulnerabilities (F-001, F-002, F-003) via dedicated commits, "
    "and perform regression retesting to ensure proper defensive closure without functionality regression.",
    body_style
))

doc.build(story)
print(f"[+] Successfully generated PDF report at: {pdf_path}")

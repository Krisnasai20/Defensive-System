# SecureNotes Security Assessment & Remediation Project

A local cybersecurity practice application built with Flask and SQLite, complete with an end-to-end defensive security assessment, sanitized evidence collection, formal reporting, targeted fixes, and regression retesting.

---

## 1. Quick Start / How to Run

### Prerequisites
- Python 3.10+ (Standard library, `Flask`, and `requests`)
- ReportLab (optional, for PDF generation: `reportlab`)

### Running the Application
```bash
# From workspace root
python app/app.py
```
The application runs locally on `http://127.0.0.1:5000`.

### Running the Assessment & Retest Suites
```bash
# Execute initial vulnerability assessment and generate evidence:
python assess.py

# Recompile the PDF assessment report:
python generate_pdf.py

# Execute the post-remediation retest suite:
python retest.py
```

### Synthetic Demo Credentials
- **Username / Email:** `tester` or `tester@example.test`
- **Password:** `Password123!`

---

## 2. File Map

```
Defence Security System/
├── .gitignore                        # Git exclusion rules (venv, temp logs, cache)
├── SCOPE.md                          # Scope, threat model (STRIDE) & Rules of Engagement
├── README.md                         # Project documentation and run guide
├── assess.py                         # Automated assessment probe runner
├── generate_pdf.py                   # ReportLab PDF report generator
├── retest.py                         # Post-fix regression verification test suite
├── app/                              # Target Flask application
│   ├── app.py                        # Application routes, database models, handlers
│   ├── notes.db                      # SQLite practice database
│   ├── requirements.txt              # Pinned dependencies
│   └── templates/                    # Jinja2 HTML templates
│       ├── base.html                 # Core layout & styling
│       ├── login.html                # User login form
│       ├── register.html             # User registration form
│       └── notes.html                # Notes dashboard & search interface
├── evidence/                         # Sanitized test evidence artifacts
│   ├── 01_configuration_headers.txt # Headers & debug mode evidence
│   ├── 02_authentication_ratelimit.txt # Weak hashing & brute-force test evidence
│   ├── 03_input_validation_sqli.txt    # SQL injection syntax & logic probes
│   ├── 04_input_validation_xss.txt     # Reflected XSS evidence
│   ├── 05_dependencies.txt          # Offline dependency advisory audit
│   ├── 06_logging.txt               # Plaintext credential logging evidence
│   └── 07_retest_verification.txt   # Post-remediation retest verification
└── report/                           # Security documentation
    ├── assessment_report.md          # Full vulnerability assessment report (Markdown)
    ├── assessment_report.pdf         # Formatted PDF report
    └── retest.md                     # Before/After retest comparison report
```

---

## 3. Summary of Findings & Remediations

| Finding ID | Title | Severity | CWE | Pre-Fix Status | Post-Fix Status | Commit Reference |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **F-001** | SQL Injection in Search Feature | **Critical** (CVSS 9.8) | CWE-89 | VULNERABLE | **CLOSED** | `fix(sqli): parameterize notes search query [F-001]` |
| **F-002** | Reflected Cross-Site Scripting (XSS) | **High** (CVSS 7.2) | CWE-79 | VULNERABLE | **CLOSED** | `fix(xss): remove raw safe filter and enforce html escaping [F-002]` |
| **F-003** | Insecure Password Hashing (MD5) | **High** (CVSS 7.5) | CWE-328 | VULNERABLE | **CLOSED** | `fix(auth): replace md5 with pbkdf2 password hashing [F-003]` |
| **F-004** | Debug Mode Active in Runtime | **High** (CVSS 7.5) | CWE-489 | VULNERABLE | Open (Backlog) | Tracked for release v1.1 |
| **F-005** | Missing Authentication Rate Limiting | **Medium** (CVSS 5.3) | CWE-307 | VULNERABLE | Open (Backlog) | Tracked for release v1.1 |
| **F-006** | Cleartext Password in Logs | **Medium** (CVSS 5.5) | CWE-532 | VULNERABLE | Open (Backlog) | Tracked for release v1.1 |
| **F-007** | Outdated Pinned Dependencies | **Medium** (CVSS 6.5) | CWE-1104 | VULNERABLE | Open (Backlog) | Tracked for release v1.1 |
| **F-008** | Missing HTTP Security Headers | **Low** (CVSS 3.7) | CWE-693 | VULNERABLE | Open (Backlog) | Tracked for release v1.1 |

---

## 4. Size Limit Compliance
Per engagement parameters, the entire repository remains under **25 MB**. Large binaries, packages, virtual environments, and video media are strictly excluded via `.gitignore`.

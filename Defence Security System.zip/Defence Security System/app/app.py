import os
import sqlite3
import hashlib
import logging
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, request, render_template, redirect, url_for, session, flash

# Setup application logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger('SecureNotesApp')

app = Flask(__name__)
# Deliberate Weakness: Hardcoded predictable secret key
app.secret_key = 'super-insecure-secret-key-12345'

DB_PATH = os.path.join(os.path.dirname(__file__), 'notes.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT NOT NULL,
            password_hash TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    conn.commit()

    # Seed initial test account if not exists
    cursor.execute('SELECT id, password_hash FROM users WHERE username = ?', ('tester',))
    existing_user = cursor.fetchone()
    secure_test_hash = generate_password_hash('Password123!')
    if not existing_user:
        cursor.execute(
            'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
            ('tester', 'tester@example.test', secure_test_hash)
        )
        user_id = cursor.lastrowid
        cursor.execute(
            'INSERT INTO notes (user_id, title, content, created_at) VALUES (?, ?, ?, ?)',
            (user_id, 'Welcome Note', 'This is a practice note for local security testing.', datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'))
        )
        cursor.execute(
            'INSERT INTO notes (user_id, title, content, created_at) VALUES (?, ?, ?, ?)',
            (user_id, 'Deployment Checklist', 'Ensure HTTPS and CSRF tokens are configured before production.', datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'))
        )
        conn.commit()
    elif not existing_user['password_hash'].startswith('pbkdf2:'):
        # Upgrade legacy MD5 hash to PBKDF2:SHA256
        cursor.execute('UPDATE users SET password_hash = ? WHERE username = ?', (secure_test_hash, 'tester'))
        conn.commit()
    conn.close()

# Password hashing helper
def hash_password(password: str) -> str:
    # Fixed [F-003]: PBKDF2-HMAC-SHA256 with cryptographically secure salt
    return generate_password_hash(password)

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('notes'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')

        if not username or not email or not password:
            flash('All fields are required.', 'error')
            return render_template('register.html')

        pwd_hash = hash_password(password)
        conn = get_db()
        cursor = conn.cursor()
        try:
            cursor.execute(
                'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                (username, email, pwd_hash)
            )
            conn.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already exists.', 'error')
        finally:
            conn.close()

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        # Deliberate Weakness: Insecure logging of sensitive credentials
        logger.info(f"Authentication attempt: username='{username}' password='{password}'")

        # Deliberate Weakness: No rate limiting on authentication
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute(
            'SELECT id, username, password_hash FROM users WHERE (username = ? OR email = ?)',
            (username, username)
        )
        user = cursor.fetchone()
        conn.close()

        # Fixed [F-003]: Verify password using constant-time PBKDF2:SHA256 check
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash('Logged in successfully.', 'success')
            return redirect(url_for('notes'))
        else:
            flash('Invalid username or password.', 'error')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))

@app.route('/notes', methods=['GET'])
def notes():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    user_id = session['user_id']
    query = request.args.get('q', '')

    conn = get_db()
    cursor = conn.cursor()

    if query:
        # Fixed [F-001]: Parameterized query prevents SQL injection
        pattern = f"%{query}%"
        cursor.execute(
            'SELECT id, title, content, created_at FROM notes WHERE user_id = ? AND (title LIKE ? OR content LIKE ?) ORDER BY id DESC',
            (user_id, pattern, pattern)
        )
        rows = cursor.fetchall()
    else:
        cursor.execute(
            'SELECT id, title, content, created_at FROM notes WHERE user_id = ? ORDER BY id DESC',
            (user_id,)
        )
        rows = cursor.fetchall()

    conn.close()

    # Fixed [F-002]: User query is rendered safely via Jinja2 auto-escaping
    return render_template(
        'notes.html',
        notes=rows,
        raw_query=query
    )

@app.route('/notes/create', methods=['POST'])
def create_note():
    if 'user_id' not in session:
        flash('Unauthorized.', 'error')
        return redirect(url_for('login'))

    user_id = session['user_id']
    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()

    if not title or not content:
        flash('Title and content are required.', 'error')
        return redirect(url_for('notes'))

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO notes (user_id, title, content, created_at) VALUES (?, ?, ?, ?)',
        (user_id, title, content, datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'))
    )
    conn.commit()
    conn.close()

    flash('Note created successfully.', 'success')
    return redirect(url_for('notes'))

# Deliberate Weakness: Missing security headers (No after_request hook setting CSP, X-Content-Type-Options, etc.)

if __name__ == '__main__':
    init_db()
    # Deliberate Weakness: debug=True enabled on local server
    app.run(host='127.0.0.1', port=5000, debug=True)
